package com.deylauncher.launch;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.io.TempDir;

import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.HashMap;
import java.util.Map;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertTrue;

/**
 * The decision table behind "start the game natively on Wayland instead of XWayland". Every branch that
 * could choose an unavailable backend is covered here on purpose: the launch must only request Wayland
 * when a Wayland socket really exists AND the GLFW native really has a Wayland backend.
 */
class WaylandSupportTest {

    /** A live Wayland session with XWayland available -- the exact shape of the machine that crashes. */
    private static Map<String, String> waylandSession(Path runtimeDir) {
        Map<String, String> env = new HashMap<>();
        env.put("WAYLAND_DISPLAY", "wayland-0");
        env.put("XDG_RUNTIME_DIR", runtimeDir.toString());
        env.put("DISPLAY", ":0");
        return env;
    }

    /** A fake natives dir whose libglfw.so carries the Wayland marker (like LWJGL 3.3.1's GLFW 3.4). */
    private static Path waylandCapableNatives(Path dir) throws Exception {
        Files.createDirectories(dir);
        Files.write(dir.resolve("libglfw.so"),
                ("\u007fELF3.4.0 Wayland X11 GLX Null EGL OSMesa monotonic shared "
                        + WaylandSupport.WAYLAND_BACKEND_SYMBOL).getBytes(StandardCharsets.ISO_8859_1));
        return dir;
    }

    /** A fake natives dir shaped like an X11-only GLFW (what Minecraft's older LWJGL versions ship). */
    private static Path x11OnlyNatives(Path dir) throws Exception {
        Files.createDirectories(dir);
        Files.write(dir.resolve("libglfw.so"),
                "\u007fELF3.3.6 X11 GLX EGL OSMesa clock_gettime monotonic shared"
                        .getBytes(StandardCharsets.ISO_8859_1));
        return dir;
    }

    @Test
    void waylandSessionIsRecognizedByItsWaylandDisplay() {
        assertTrue(WaylandSupport.inWaylandSession(Map.of("WAYLAND_DISPLAY", "wayland-0")));
        // A plain X11 login sets DISPLAY only -- no Wayland, nothing to switch to.
        assertFalse(WaylandSupport.inWaylandSession(Map.of("DISPLAY", ":0")));
        assertFalse(WaylandSupport.inWaylandSession(Map.of("WAYLAND_DISPLAY", "  ")));
        assertFalse(WaylandSupport.inWaylandSession(null));
    }

    @Test
    void socketIsResolvedRelativeToTheRuntimeDirUnlessItIsAbsolute() {
        assertEquals(Path.of("/run/user/1000/wayland-0"),
                WaylandSupport.waylandSocket(Map.of("WAYLAND_DISPLAY", "wayland-0",
                        "XDG_RUNTIME_DIR", "/run/user/1000")));
        assertEquals(Path.of("/tmp/sock"),
                WaylandSupport.waylandSocket(Map.of("WAYLAND_DISPLAY", "/tmp/sock")));
        assertNull(WaylandSupport.waylandSocket(Map.of("WAYLAND_DISPLAY", "wayland-0")));
        assertNull(WaylandSupport.waylandSocket(Map.of("XDG_RUNTIME_DIR", "/run/user/1000")));
    }

    @Test
    void glfwWithAwaylandBackendIsDetectedAndWithoutOneIsNot(@TempDir Path tmp) throws Exception {
        assertTrue(WaylandSupport.glfwHasWaylandBackend(waylandCapableNatives(tmp.resolve("wl"))));
        assertFalse(WaylandSupport.glfwHasWaylandBackend(x11OnlyNatives(tmp.resolve("x11"))));
        // Nothing downloaded yet (or an unreadable native) must mean "don't touch the launch".
        assertFalse(WaylandSupport.glfwHasWaylandBackend(tmp.resolve("missing")));
        assertFalse(WaylandSupport.glfwHasWaylandBackend(null));
    }

    @Test
    void nativeWaylandIsRequestedWithoutRemovingDisplay(@TempDir Path tmp) throws Exception {
        Path runtime = Files.createDirectories(tmp.resolve("run"));
        Files.createFile(runtime.resolve("wayland-0"));
        Map<String, String> env = waylandSession(runtime);
        Path natives = waylandCapableNatives(tmp.resolve("natives"));

        assertTrue(WaylandSupport.enableNativeWayland(true, "Linux", env, natives));
        assertEquals(":0", env.get("DISPLAY"), "DISPLAY must remain for AWT and X11-using mods");
        assertEquals("wayland", env.get("GLFW_PLATFORM"));
        assertTrue(env.containsKey("WAYLAND_DISPLAY"), "the Wayland socket name must survive untouched");
    }

    @Test
    void anX11SessionKeepsItsDisplay(@TempDir Path tmp) throws Exception {
        Path natives = waylandCapableNatives(tmp.resolve("natives"));
        Map<String, String> env = new HashMap<>();
        env.put("DISPLAY", ":0");

        assertFalse(WaylandSupport.enableNativeWayland(true, "Linux", env, natives));
        assertEquals(":0", env.get("DISPLAY"));
    }

    @Test
    void aVanishedWaylandSocketKeepsTheXWaylandLaunch(@TempDir Path tmp) throws Exception {
        // Wayland advertised in the environment but the compositor's socket is gone: switching the game to
        // Wayland here would leave it with no display at all, so the launch must stay on XWayland.
        Path runtime = Files.createDirectories(tmp.resolve("run"));
        Path natives = waylandCapableNatives(tmp.resolve("natives"));
        Map<String, String> env = waylandSession(runtime);

        assertFalse(WaylandSupport.shouldUseNativeWayland(true, "Linux", env, natives));
        assertFalse(WaylandSupport.enableNativeWayland(true, "Linux", env, natives));
        assertEquals(":0", env.get("DISPLAY"));
    }

    @Test
    void oldGlfwWithoutAwaylandBackendIsNeverSwitched(@TempDir Path tmp) throws Exception {
        Path runtime = Files.createDirectories(tmp.resolve("run"));
        Files.createFile(runtime.resolve("wayland-0"));
        Map<String, String> env = waylandSession(runtime);

        assertFalse(WaylandSupport.enableNativeWayland(true, "Linux", env, x11OnlyNatives(tmp.resolve("natives"))));
        assertEquals(":0", env.get("DISPLAY"));
    }

    /** A version JSON whose libraries declare a given LWJGL core version, the way every real one does. */
    private static JsonObject versionJsonWithLwjgl(String lwjglVersion) {
        JsonObject version = new JsonObject();
        JsonArray libraries = new JsonArray();
        JsonObject lwjgl = new JsonObject();
        lwjgl.addProperty("name", "org.lwjgl:lwjgl:" + lwjglVersion);
        libraries.add(lwjgl);
        JsonObject glfw = new JsonObject();
        glfw.addProperty("name", "org.lwjgl:lwjgl-glfw:" + lwjglVersion);
        libraries.add(glfw);
        version.add("libraries", libraries);
        return version;
    }

    @Test
    void lwjglVersionIsReadFromTheCoreLibraryEntry() {
        assertEquals("3.3.1", WaylandSupport.lwjglVersion(versionJsonWithLwjgl("3.3.1")));
        assertEquals("3.4.1-snapshot", WaylandSupport.lwjglVersion(versionJsonWithLwjgl("3.4.1-snapshot")));
        assertNull(WaylandSupport.lwjglVersion(null));
        assertNull(WaylandSupport.lwjglVersion(new JsonObject()));
    }

    @Test
    void modpackShapedLwjgl331IsNotSafeForNativeWayland_butNormalInstanceLwjgl341Is(@TempDir Path tmp) throws Exception {
        // The exact split reported in the field: a 1.20.1-shaped MODPACK bundling LWJGL 3.3.1 crashes
        // (SIGSEGV inside libglfw.so, before any GPU work) when native Wayland is requested, while a
        // "normal"/custom instance on a current Minecraft build (LWJGL 3.4.1) does not. Both natives pass
        // the plain byte-search (glfwHasWaylandBackend) -- the version-aware overload is what tells them
        // apart.
        Path runtime = Files.createDirectories(tmp.resolve("run"));
        Files.createFile(runtime.resolve("wayland-0"));
        Map<String, String> env = waylandSession(runtime);
        Path natives = waylandCapableNatives(tmp.resolve("natives"));

        assertFalse(WaylandSupport.shouldUseNativeWayland(true, "Linux", env, natives, versionJsonWithLwjgl("3.3.1")),
                "LWJGL 3.3.1's Wayland backend is known to crash on window creation -- must stay on XWayland");
        assertTrue(WaylandSupport.shouldUseNativeWayland(true, "Linux", env, natives, versionJsonWithLwjgl("3.4.1-snapshot")),
                "LWJGL 3.4.1 is the known-good build this class was originally built around");
        // Exactly at the safe floor, and one patch below it.
        assertTrue(WaylandSupport.shouldUseNativeWayland(true, "Linux", env, natives, versionJsonWithLwjgl("3.3.2")));
        assertFalse(WaylandSupport.shouldUseNativeWayland(true, "Linux", env, natives, versionJsonWithLwjgl("3.3.0")));
        // A version JSON with no LWJGL declared at all (or none passed) must never be assumed safe.
        assertFalse(WaylandSupport.shouldUseNativeWayland(true, "Linux", env, natives, new JsonObject()));
        assertFalse(WaylandSupport.shouldUseNativeWayland(true, "Linux", env, natives, null));

        assertFalse(WaylandSupport.enableNativeWayland(true, "Linux", env, natives, versionJsonWithLwjgl("3.3.1")));
        assertEquals(":0", env.get("DISPLAY"));
        assertFalse(env.containsKey("GLFW_PLATFORM"));

        Map<String, String> env2 = waylandSession(runtime);
        assertTrue(WaylandSupport.enableNativeWayland(true, "Linux", env2, natives, versionJsonWithLwjgl("3.4.1-snapshot")));
        assertEquals("wayland", env2.get("GLFW_PLATFORM"));
    }

    @Test
    void windowsAndTheUntickedOptionAlwaysKeepTheEnvironment(@TempDir Path tmp) throws Exception {
        Path runtime = Files.createDirectories(tmp.resolve("run"));
        Files.createFile(runtime.resolve("wayland-0"));
        Path natives = waylandCapableNatives(tmp.resolve("natives"));

        Map<String, String> windows = waylandSession(runtime);
        windows.put("WAYLAND_DISPLAY", "");
        assertFalse(WaylandSupport.enableNativeWayland(true, "Windows 11", windows, natives));

        Map<String, String> optedOut = waylandSession(runtime);
        assertFalse(WaylandSupport.enableNativeWayland(false, "Linux", optedOut, natives));
        assertEquals(":0", optedOut.get("DISPLAY"));
    }

    @Test
    void usesBuggyLwjglDetects331AndNotOthers() {
        assertTrue(WaylandSupport.usesBuggyLwjgl(versionJsonWithLwjgl("3.3.1")));
        assertFalse(WaylandSupport.usesBuggyLwjgl(versionJsonWithLwjgl("3.3.2")));
        assertFalse(WaylandSupport.usesBuggyLwjgl(versionJsonWithLwjgl("3.4.1")));
        assertFalse(WaylandSupport.usesBuggyLwjgl(versionJsonWithLwjgl("3.4.1-snapshot")));
        assertFalse(WaylandSupport.usesBuggyLwjgl(new JsonObject()));
        assertFalse(WaylandSupport.usesBuggyLwjgl(null));
    }

    @Test
    void patchLwjglVersionUpgrades331To333AndRemovesDownloads(@TempDir Path tmp) throws Exception {
        JsonObject version = versionJsonWithLwjgl("3.3.1");
        // Add a downloads object to one of the libraries to verify it gets removed
        JsonArray libs = version.getAsJsonArray("libraries");
        for (JsonElement el : libs) {
            JsonObject lib = el.getAsJsonObject();
            if (lib.get("name").getAsString().contains("lwjgl-glfw")) {
                lib.addProperty("downloads", "should be removed");
                break;
            }
        }

        assertTrue(WaylandSupport.patchLwjglVersion(version));

        // Verify the version was updated
        for (JsonElement el : version.getAsJsonArray("libraries")) {
            JsonObject lib = el.getAsJsonObject();
            String name = lib.get("name").getAsString();
            assertFalse(name.contains(":3.3.1"), "Library still has 3.3.1: " + name);
            assertTrue(name.contains(":3.3.3"), "Library doesn't have 3.3.3: " + name);
            // downloads should be removed
            assertFalse(lib.has("downloads"), "downloads object was not removed from " + name);
        }

        // Second call should return false (no more 3.3.1 to patch)
        assertFalse(WaylandSupport.patchLwjglVersion(version));
    }

    @Test
    void patchLwjglVersionSkipsNonLwjglLibraries() {
        JsonObject version = new JsonObject();
        JsonArray libraries = new JsonArray();
        // Add a non-LWJGL library
        JsonObject other = new JsonObject();
        other.addProperty("name", "com.example:some-lib:1.0");
        libraries.add(other);
        // Add LWJGL 3.3.1
        JsonObject lwjgl = new JsonObject();
        lwjgl.addProperty("name", "org.lwjgl:lwjgl:3.3.1");
        libraries.add(lwjgl);
        version.add("libraries", libraries);

        assertTrue(WaylandSupport.patchLwjglVersion(version));

        // The non-LWJGL library should be unchanged
        JsonObject otherLib = version.getAsJsonArray("libraries").get(0).getAsJsonObject();
        assertEquals("com.example:some-lib:1.0", otherLib.get("name").getAsString());
        // The LWJGL library should be patched
        JsonObject lwjglLib = version.getAsJsonArray("libraries").get(1).getAsJsonObject();
        assertEquals("org.lwjgl:lwjgl:3.3.3", lwjglLib.get("name").getAsString());
    }
}
