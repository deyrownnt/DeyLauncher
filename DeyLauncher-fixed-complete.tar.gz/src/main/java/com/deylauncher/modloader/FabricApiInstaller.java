package com.deylauncher.modloader;

import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;

import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;

/**
 * Fabric API ships bundled with every DEY Fabric build -- most Fabric mods (Sodium included,
 * for some versions) declare it as a dependency, so having it missing is a common source of
 * "the game won't even start" reports. Fetched from Modrinth's public, documented API, the
 * same integration point SodiumInstaller and FabricInstaller already use.
 *
 * Fabric API is Fabric/Quilt-only by definition -- there's no Forge build and no Forge
 * equivalent to substitute (Forge's own API is built into Forge itself), so this only runs
 * for DEY Fabric instances, never Forge ones.
 */
public class FabricApiInstaller {

    private static final String PROJECT_SLUG = "fabric-api";
    private static final String LOADER_NAME = "fabric";

    private final HttpClient http = HttpClient.newHttpClient();

    /** True if a fabric-api-*.jar is already present in this instance's mods folder. */
    public boolean isInstalled(Path modsDir) throws Exception {
        if (!Files.isDirectory(modsDir)) return false;
        String prefix = familyPrefix();
        try (var stream = Files.list(modsDir)) {
            return stream.anyMatch(p -> p.getFileName().toString().toLowerCase().startsWith(prefix));
        }
    }

    private String familyPrefix() {
        return PROJECT_SLUG.toLowerCase() + "-";
    }

    /**
     * Ensures the Fabric API build matching mcVersion is installed and is the ONE that runs. Only
     * EXACTLY matching Minecraft versions are considered, preferring stable releases. A stale
     * /wrong-version fabric-api jar is replaced (updated/downgraded) -- never just deleted. If Modrinth
     * has no build for this EXACT version, any existing active fabric-api jar is moved to mods-disabled
     * (disabled, NOT deleted) so the game still loads. Returns the file's name, a "DISABLED:<names>"
     * marker, or null.
     */
    public String ensureInstalled(String mcVersion, Path modsDir) throws Exception {
        String listUrl = "https://api.modrinth.com/v2/project/" + PROJECT_SLUG + "/version";
        HttpRequest req = HttpRequest.newBuilder(URI.create(listUrl))
                .header("User-Agent", "DeyLauncher/0.1 (+" + PROJECT_SLUG + "-auto-install)")
                .GET().build();
        HttpResponse<String> resp = http.send(req, HttpResponse.BodyHandlers.ofString());
        if (resp.statusCode() != 200) {
            throw new IllegalStateException("Modrinth request failed: HTTP " + resp.statusCode());
        }
        JsonArray versions = JsonParser.parseString(resp.body()).getAsJsonArray();

        JsonObject best = findBestCompatible(versions, mcVersion);
        if (best == null) {
            // No build supports this EXACT Minecraft version. Never delete Fabric API to "fix" it --
            // disable (move to mods-disabled) any active Fabric API jar so the game still loads.
            java.util.List<String> disabled = ModsUtil.disableActiveFamily(modsDir, familyPrefix());
            if (!disabled.isEmpty()) return "DISABLED:" + String.join(",", disabled);
            return null;
        }

        JsonObject file = primaryFile(best.getAsJsonArray("files"));
        String fileName = file.get("filename").getAsString();
        String prefix = familyPrefix();
        Files.createDirectories(modsDir);

        Path active = ModsUtil.firstFamilyJar(modsDir, prefix);
        if (active != null && active.getFileName().toString().equalsIgnoreCase(fileName)) {
            return null; // the exact matching build is already installed
        }

        // Prefer re-enabling an exact copy already sitting in mods-disabled to re-downloading it.
        Path disabledCopy = ModsUtil.disabledDirFor(modsDir).resolve(fileName);
        if (Files.exists(disabledCopy) && ModsUtil.reenableDisabled(modsDir, disabledCopy)) {
            ModsUtil.removeFamilyJarsExcept(modsDir, prefix, fileName);
            return fileName;
        }

        Path dest = modsDir.resolve(fileName);
        Path tmp = modsDir.resolve(fileName + ".part");
        HttpResponse<Path> fileResp = http.send(
                HttpRequest.newBuilder(URI.create(file.get("url").getAsString())).GET().build(),
                HttpResponse.BodyHandlers.ofFile(tmp));
        if (fileResp.statusCode() != 200) {
            Files.deleteIfExists(tmp);
            throw new IllegalStateException(PROJECT_SLUG + " download failed: HTTP " + fileResp.statusCode());
        }
        Files.move(tmp, dest, StandardCopyOption.REPLACE_EXISTING);

        // Replace: drop any other (stale / wrong-version) fabric-api jar -- an update/downgrade, not a bare delete.
        ModsUtil.removeFamilyJarsExcept(modsDir, prefix, fileName);
        return fileName;
    }

    /** Newest EXACT-matching build, preferring stable releases over pre-releases. */
    private JsonObject findBestCompatible(JsonArray versions, String mcVersion) {
        JsonObject newest = null, newestStable = null;
        for (var el : versions) {
            JsonObject v = el.getAsJsonObject();
            if (!supportsLoader(v) || !supportsVersion(v, mcVersion)) continue;
            JsonArray files = v.getAsJsonArray("files");
            if (files == null || files.isEmpty()) continue;
            if (newest == null) newest = v;
            if (!isPreRelease(v)) {
                if (newestStable == null) newestStable = v;
            }
        }
        return newestStable != null ? newestStable : newest;
    }

    /** True when a version number looks like an alpha/beta/pre/snapshot/dev build. */
    private boolean isPreRelease(JsonObject v) {
        String num = v.has("version_number") ? v.get("version_number").getAsString().toLowerCase() : "";
        return num.contains("alpha") || num.contains("beta") || num.contains("pre")
                || num.contains("snapshot") || num.contains("dev") || num.contains("nightly");
    }

    private boolean supportsLoader(JsonObject version) {
        if (!version.has("loaders")) return false;
        for (var l : version.getAsJsonArray("loaders")) {
            if (l.getAsString().equalsIgnoreCase(LOADER_NAME)) return true;
        }
        return false;
    }

    private boolean supportsVersion(JsonObject version, String mcVersion) {
        if (!version.has("game_versions")) return false;
        for (var gv : version.getAsJsonArray("game_versions")) {
            if (gv.getAsString().equals(mcVersion)) return true;
        }
        return false;
    }

    private JsonObject primaryFile(JsonArray files) {
        for (var f : files) {
            JsonObject obj = f.getAsJsonObject();
            if (obj.has("primary") && obj.get("primary").getAsBoolean()) return obj;
        }
        return files.get(0).getAsJsonObject();
    }
}
